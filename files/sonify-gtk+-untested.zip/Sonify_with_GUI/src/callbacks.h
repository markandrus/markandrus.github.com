#include <gnome.h>


void
on_txt_input_image_changed             (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_txt_output_image_changed            (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spn_lower_bounds_changed            (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spn_pitch_scale_changed             (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_txt_waveform_type_changed           (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_btn_quit_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_tgl_on_off_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_spn_pixel_time_changed              (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_sonify_app_destroy                  (GtkObject       *object,
                                        gpointer         user_data);

void
on_tgl_on_off_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
