#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gnome.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

extern char *global_file_name;
extern char *global_file_name2;
extern int lower_bounds;
extern int pitch_scale;
enum TYPE {Sine = 0, Square, Triangle, Sawtooth};
extern enum TYPE waveform_type;
extern int off;
extern float ms_time;
extern void init_aubio();

void
on_txt_input_image_changed             (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_input_image = lookup_widget(GTK_ENTRY(editable), "txt_input_image");
	global_file_name = gtk_entry_get_text(GTK_ENTRY(editable));
}


void
on_txt_output_image_changed            (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_output_image = lookup_widget(GTK_ENTRY(editable), "txt_output_image");
	global_file_name2 = gtk_entry_get_text(GTK_ENTRY(editable));
}


void
on_spn_lower_bounds_changed            (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_output_image = lookup_widget(GTK_SPIN_BUTTON(editable), "spn_lower_bounds");
	lower_bounds = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(editable));
}


void
on_spn_pitch_scale_changed             (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_output_image = lookup_widget(GTK_SPIN_BUTTON(editable), "spn_pitch_scale");
	pitch_scale = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(editable));
}


void
on_txt_waveform_type_changed           (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_output_image = lookup_widget(GTK_ENTRY(editable), "txt_waveform_type");
	char *value = gtk_entry_get_text(GTK_ENTRY(editable));
	if (value == "0" || value == "sine") {
		waveform_type = 0;		
	} else if (value == "1" || value == "square") {
		waveform_type = 1;
	} else if (value == "2" || value == "triangle") {
		waveform_type = 2;
	} else if (value == "3" || value == "sawtooth") {
		waveform_type = 3;
	}
}


void
on_btn_quit_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	exit(0);
}

void
on_spn_pixel_time_changed              (GtkEditable     *editable,
                                        gpointer         user_data)
{
	//GtkWidget * txt_spn_pixel_time = lookup_widget(GTK_SPIN_BUTTON(editable), "spn_pixel_time");
	ms_time = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(editable));
}


void
on_sonify_app_destroy                  (GtkObject       *object,
                                        gpointer         user_data)
{
	exit(0);
}


void
on_tgl_on_off_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (off == 2) {
		off = 1;
	} else {
		off = abs(abs(off) - 1);
	}
}

