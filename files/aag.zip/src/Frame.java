import java.util.ArrayList;

public class Frame {
	public ArrayList<ArrayList> particleGroups;
	
	public Frame() {
		particleGroups = new ArrayList<ArrayList>();
	}
	public Frame(ArrayList<ArrayList> ParticleGroups) {
		particleGroups = ParticleGroups;
	}
	
	public void add(int i, Particle p) {
		ArrayList<Particle> pg = particleGroups.get(i);
		pg.add(p);
	}
	
	public void addGroup(ArrayList<Particle> pg) {
		particleGroups.add(pg);
	}
	
	// stepAll
	public void stepAll(int pg_k) {
		ArrayList<Particle> pg = particleGroups.get(pg_k);
		for (int i = 0; i < pg.size(); i++) {
			pg.get(i).step(pg);
		}
	}
	
	
}
